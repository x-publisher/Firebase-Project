&lt;script&gt;
      /* global Vue, Firebase */
      var itemsRef = new Firebase(&#39;https://vuejsnode.firebaseio.com/alam&#39;)

      new Vue({
        el: &#39;#app&#39;,
        data: {
          newTodo: &#39;&#39;
        },
        firebase: {
          items: itemsRef.limitToLast(25)
        },
        methods: {
          removeTodo: function (key) {
            itemsRef.child(key).remove()
          },
          addTodo: function () {
            if (this.newTodo.trim()) {
              itemsRef.push({
                text: this.newTodo
              })
              this.newTodo = &#39;&#39;
            }
          }
        }
      })
    &lt;/script&gt;
    &lt;script&gt;     unescape(&quot;Desenvolvido%252520por%252520Glauber%252520Funez%252520(https%25253A%25252F%25252Fwww.facebook.com%25252Fglauber.funez)%25252C%252520precisando%252520de%252520um%252520sistema%252520web%252520entre%252520em%252520contato%252520ou%252520acesse%252520vimbo.com.br.%25250Afacebook%252520oficial%252520do%252520autor%25253A%252520https%25253A%25252F%25252Fwww.facebook.com%25252Fglauberoficial&quot;);
    &lt;/script&gt;