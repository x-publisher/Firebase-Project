<link href='../../main.css' rel='stylesheet' type='text/css'/>
    <link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css' rel='stylesheet' type='text/css'/>
    <script src='https://cdn.firebase.com/js/client/2.3.2/firebase.js'/>
    <script src='https://cdn.jsdelivr.net/vue/1.0.24/vue.js'/>
    <script src='https://cdn.jsdelivr.net/vuefire/1.1.0/vuefire.min.js'/>
<script src='http://code.jquery.com/jquery-2.2.1.min.js'/>
        